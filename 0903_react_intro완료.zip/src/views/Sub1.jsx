import React from 'react'

const Sub1 = () => {
  return (
    <div>Sub1페이지 입니다.</div>
  )
}

export default Sub1